import MainView from "./views/MainView";
function App() {
  return <MainView></MainView>;
}

export default App;
